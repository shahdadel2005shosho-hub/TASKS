#ifndef MATRIX_H
#define MATRIX_H

typedef struct {
    int rows;
    int cols;
    int data[10][10];
} Matrix;

void inputMatrix(Matrix *m);
void printMatrix(Matrix m);

Matrix addMatrix(Matrix a, Matrix b);
Matrix subtractMatrix(Matrix a, Matrix b);

#endif