#include <stdio.h>
#include "matrix.h"

int main() {
    Matrix m1, m2, sum, sub;

    m1.rows = 2;
    m1.cols = 2;
    m2.rows = 2;
    m2.cols = 2;

    printf("Enter matrix 1:\n");
    inputMatrix(&m1);

    printf("Enter matrix 2:\n");
    inputMatrix(&m2);

    sum = addMatrix(m1, m2);
    sub = subtractMatrix(m1, m2);

    printf("Sum:\n");
    printMatrix(sum);

    printf("Subtraction:\n");
    printMatrix(sub);

    return 0;
}